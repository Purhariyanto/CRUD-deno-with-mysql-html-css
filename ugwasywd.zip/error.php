<?php
header('Location: /');