<?php

$apiclient4=array('AIzaSyDPG1arhbci1YFXQuoncSVgQewQZA8-XPk','AIzaSyAy7UmB0qpMnBOXS5dunwIYKWSmo6Rd6W4','AIzaSyAuLLyx7wya9XSVPJzhW6diva5oqbRZJT0');

$apiclient3=array('AIzaSyA-dlBUjVQeuc4a6ZN4RkNUYDFddrVLxrA');

$apiclient2=array('AIzaSyCjpOI2pdJHMuVEkL4NWi2-g8JAoGeFPvM','AIzaSyCArpalL2OwbZLg_fyMyzXX5DByLy8Xd3w','AIzaSyDUR1GYxrrN3Qt41A72Uo6PGk-taKMmP68');

$apiclient1=array('AIzaSyDjWLYYPQfwsINCb5gAT5dvOWVlb0YQly0','AIzaSyDXzycFeqppwakc3ZL56KgQGQECe99D6IY','AIzaSyAcUxYNm87t5X45zHKfyL_uifmqXI4lvlw','AIzaSyBdc8Um8gpsE57SS8ddGGde11j7Vwr0tzM');

$apiclient=array('AIzaSyA0kZlvJJ6FqJMiVkiR35laFK8sRDT4E8k','AIzaSyAB5bAk5U6hLVYSr7IxMKL5uhJqmnloPF0','AIzaSyCZyCwEIFd-Umu5ivHCmuh5MrgiPXkaPYA','AIzaSyAZMofUgFi0_sxm4VQOoR7iH8UYKN0P5k0','AIzaSyCJgOV42ZWvmkSwKz6k-RYabpwsAsA5uW8');
$ngacak=array_rand($apiclient3);
$mapi=$apiclient3[$ngacak];
$apikey = ''.$mapi.'';
$sitename = 'Dlagu';
$apikey1 = 'AIzaSyApxIgZj-MOzIfm8tLM4CwqHFZO1OxHH-4';
?>