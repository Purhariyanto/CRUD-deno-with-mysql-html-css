<?php
echo '<div class="content" align="center"><a href="/page/about.php">About</a> · <a href="/page/contact.php">Contact</a> · <a href="/page/disclaimer.php">Disclaimer</a> · <a href="/page/privacy.php">Privacy Policy</a> · <a href="/page/t&c.php">Terms & Conditions</a></div>';
echo '<div class="footer" align="center">&copy; '.date('Y').' Dlagu</div>';
echo '</div>';
echo '</body></html>';
