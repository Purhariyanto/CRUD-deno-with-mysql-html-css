<?php
$block = ['bokep', 'missing-nine-full-ost', 'download-lagu-india-versi-dj', 'bkd-warning-pns-harus-patuhi-pp-53', 'storm-warned-audiobook-by-dani-harper'];

$blockdl = ['N5UQrieWaQo', 'Kg0gD0IvRBs', 'Kys942N1Xlc', 'Truk', 'Bus'];
?>