<?php
function grab($url){
  // inisialisasi CURL
  $data = curl_init();
  // setting CURL
  curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($data, CURLOPT_URL, $url);
  // menjalankan CURL untuk membaca isi file
  $hasil = curl_exec($data);
  curl_close($data);
  return $hasil;
}

function ambil($url){
  $data = curl_init();
  curl_setopt($data, CURLOPT_FAILONERROR, true); 
  curl_setopt($data, CURLOPT_FOLLOWLOCATION, true); 
  curl_setopt($data, CURLOPT_RETURNTRANSFER, true); 
  curl_setopt($data, CURLOPT_SSL_VERIFYHOST, false); 
  curl_setopt($data, CURLOPT_SSL_VERIFYPEER, false); 
  curl_setopt($data, CURLOPT_URL, $url);
  $hasil = curl_exec($data);
  curl_close($data);
  return $hasil;
}

function crop($awal, $akhir, $text){
$text = explode($awal, $text);
$text = explode($akhir, $text[1]);
$text = $text[0];
return $text;
}

function base64url_encode($data) { 
  return rtrim(strtr(base64_encode($data), '+/', '-_'), '='); 
} 

function base64url_decode($data) { 
  return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT)); 
}

function bot() {

  return (
    isset($_SERVER['HTTP_USER_AGENT'])
    && preg_match('/bot|crawl|slurp|spider|mediapartners/i', $_SERVER['HTTP_USER_AGENT'])
  );
}
?>