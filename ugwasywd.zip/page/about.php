<?php
$title = 'About';
include '../includes/head1.php';
echo '<div class="header" align="center"><h2>About Dlagu</h2></div>';
echo '<div class="menu" align="justify">';
echo 'Dlagu - Gudang download lagu mp3 hot, download lagu mp3 terbaru 2019, download lagu gratis, dengarkan lagu mp3 online gratis, download lagu mp3 terbaru gratis dan download musik berkualitas tinggi di desktop dan ponsel.';
echo '</div>';
include '../includes/foot.php';
?>
