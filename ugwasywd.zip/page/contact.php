<?php
$title = 'Contact';
include '../includes/head1.php';
echo '<div class="header" align="center"><h2>Contact Dlagu</h2></div>';
echo '<div class="menu" align="justify">';
echo '<form action="" method="post" enctype="text/plain">
<table BORDER="0" CELLSPACING="0" CELLPADDING="4" WIDTH="90%">
<tr><td width="30%"><div align="right">
<b>Nama:</B></DIV></TD><td width="70%"><input type="text" name="name" size="20"></TD></TR>
<tr><td><div align="right">
<b>Email:</B></DIV></TD><td><input type="text" name="email" size="20"></TD></TR><tr><td><div align="right">
<b>Komentar:</B></DIV></TD><td><textarea name="comment" cols="30" wrap="virtual" rows="4"></TEXTAREA></TD></TR>
<tr><td>&nbsp;</TD><td><input type="submit" name="submit" value="kirim"><input type="reset" name="reset" value="hapus"></TD></TR>
</TABLE></FORM>';
echo '</div>';
include '../includes/foot.php';
?>
