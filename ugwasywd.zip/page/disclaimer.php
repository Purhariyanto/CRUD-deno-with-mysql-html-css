<?php
$title = 'Disclaimer';
include '../includes/head1.php';
echo '<div class="header" align="center"><h2>Disclaimer Dlagu</h2></div>';
echo '<div class="menu" align="justify">';
echo '<ul>
<li> News-manga.com does not host any of the files displayed on this site.</li>
<li> News-manga.com indexes these files which are located on remote servers which neither News-manga.com nor its affiliates have any connection with / control of / association with.</li>
<li> You download mp3 or video files from another host service. (not from News-manga.com)</li>
<li> All music and video on is presented only for fact-finding listening or watching.</li>
<li> You must remove a song from the computer after listening or watching.</li>
<li> If You won&apos;t delete files from the computer, You&apos;ll break the copyrights protection laws.</li>
<li> All the rights on the songs are the property of their respective owners.</li>
</ul>';
echo '</div>';
include '../includes/foot.php';
?>
