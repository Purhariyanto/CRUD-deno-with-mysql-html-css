<?php include'fungsi.php'; ?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta name="robots" content="nofollow,noindex,noodp" />
<style>body{margin:0;}</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" type="6b97ee8571f0e53967344774-text/javascript"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.9/mediaelementplayer.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.9/mediaelement-and-player.min.js" type="6b97ee8571f0e53967344774-text/javascript"></script>
<script type="6b97ee8571f0e53967344774-text/javascript">
	$(document).ready(function(){
	$('audio,video').mediaelementplayer();
	})
</script>
</head>
<audio src="https://www.youtube.com/watch?v=<?=base64url_decode($_GET['id'])?>" type="video/youtube" controls style="width: 100%">Your browser does not support the audio element</audio>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="6b97ee8571f0e53967344774-|49" defer=""></script>
</html>
