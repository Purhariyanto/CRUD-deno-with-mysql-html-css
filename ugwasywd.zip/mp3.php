<?php
include 'functions/youtube-func.php';
include 'fungsi.php';
$yf=ngegrab('https://www.googleapis.com/youtube/v3/videos?key=AIzaSyA-dlBUjVQeuc4a6ZN4RkNUYDFddrVLxrA&part=snippet,contentDetails,statistics,status,topicDetails&id='.base64url_decode($_GET['id']).'');
$yf=json_decode($yf);
if($yf)
{
foreach ($yf->items as $item)
{
$title = $item->snippet->title;
$title = ucwords(cleaned($title));
$title = str_replace('-',' ', $title);
$description = $title.' hanya untuk review saja.';
include 'includes/head1.php';
echo '<div class="menu" align="center">';
/* echo '<p><center>Tolong bantu subscribe channel youtube ini<br /><br /><script src="https://apis.google.com/js/platform.js"></script><div class="g-ytsubscribe" data-channelid="UCOcRTkd5o-puBPWOmmQP83Q" data-layout="default" data-count="default"></div></center></p>'; */
echo '<br/>Jika Link Download MP3 Tidak Keluar, Silahkan Refresh Halaman Ini !<br/><br/>';
echo 'Link Download<br/>
↓ ↓ ↓';
echo '<br><br><iframe src="https://y-api.org/button/?v='.base64url_decode($_GET['id']).'&f=mp3&bc=#0087ff" FRAMEBORDER="0" MARGINWIDTH="0" MARGINHEIGHT="0" SCROLLING="no" width="200px" height="40px"></iframe><br>';
echo '</div>';
}
}
include 'includes/foot.php';
?>
