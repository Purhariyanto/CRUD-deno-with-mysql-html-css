<?php
include 'functions/youtube-func.php';
include 'fungsi.php';
$title = 'DLagu - Download Lagu Terbaru '.date('Y');
$description = 'Dlagu - Gudang download lagu mp3 hot, download lagu mp3 terbaru 2019, download lagu gratis, dengarkan lagu mp3 online gratis, download lagu mp3 terbaru gratis dan download musik berkualitas tinggi di desktop dan ponsel.'; //Add Description
$keywords = 'Dlagu, stafaband, Planetlagu, Matikiri, lagu, download lagu, download lagu  mp3, download lagu terbaru, download lagu  gratis, musik, download musik';
include 'includes/head.php';

echo '<div class="musics_list">';
$a = file_get_contents('https://spotifycharts.com/regional/global/daily/latest');
$a = explode('<td class="chart-table-track">',$a);
for ($i=1; $i <=30 ; $i++) {
  $b = crop('<strong>','</span>',$a[$i]);
  $c = explode('</strong>',$b);
  $d = explode('<span>',$b);
  $e = $d[1].' '.$c[0];
  $e = str_replace('by ','',$e);
  $url = cleaned(str_replace('acute','',$e));
    echo '<div class="ok">';
      echo '<a href="/download/'.trim($url, "-").'">';
          echo $e;
      echo '</a>';
    echo '</div>';
}
echo '</div>';
include 'includes/foot.php';
