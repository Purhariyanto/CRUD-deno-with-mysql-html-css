//Ola k ace
if (document.URL.match(/http\:\/\/resultvideo.info/i)) {
    $('.btn-success').fadeIn(1000);
    $('#ytd').click(function() {
        $('#ytd').text('Download Started')
    });
    var Complete = "";
    var s = {
        1: "fzaqn",
            2: "agobe",
            3: "topsa",
            4: "hcqwb",
            5: "gdasz",
            6: "iooab",
            7: "idvmg",
            8: "bjtpp",
            9: "sbist",
            10: "gxgkr",
            11: "njmvd",
            12: "trciw",
            13: "sjjec",
            14: "puust",
            15: "ocnuq",
            16: "qxqnh",
            17: "jureo",
            18: "obdzo",
            19: "wavgy",
            20: "qlmqh",
            21: "avatv",
            22: "upajk",
            23: "tvqmt",
            24: "xqqqh",
            25: "xrmrw",
            26: "fjhlv",
            27: "ejtbn",
            28: "urynq",
            29: "tjljs",
            30: "ywjkg"
    };

    function DownloadVideo(Sid, Hash) {

        $('#status').html('<div id="endconvert" style="margin-top:3px;">   <b>Mp3 Ready</b>.<br /> Click the download button to start the download.</div>');
        NewUrlMp3 = 'http://' + s[Sid] + '.yt-downloader.org/download.php?id=' + Hash;
        $('.hrefdownload').addClass( "icon-download" );
        $('.hrefdownload').removeClass(  "icon-waiting" );
        $('.hrefdownload').attr('href', NewUrlMp3).show();
        $('.hrefdownload').attr('target', "_blank");
        $('.redBox').remove();  
        $( '.greenBox' ).show();              
        $('#ytd').html('<div id="save">&raquo; DOWNLOAD MP3 &laquo;</div>')
    }

    function ConvertVideo(Video, Hash) {
        var Info = new Array('Checking', 'Loading', 'Converting');
        $.ajax({
            url: 'http://d.yt-downloader.org/progress.php',
            dataType: 'jsonp',
            data: {
                id: Hash
            },
            success: function(Data) {
                if (0 < Data.error) {
                    Complete = true;
                    $('#converter').before('<div id="error">' + Ea.convert[Data.error] + '<br/><a href="">Please try to Download other option.</a></div>');
                    $.ajax({
                        url: 'error.php',
                        async: false,
                        cache: false,
                        type: 'POST',
                        data: {
                            f: 2,
                            e: Data.error,
                            s: Data.sid,
                            v: Video,
                            h: Hash
                        }
                    })
                }
                switch (parseInt(Data.progress)) {
                    case 0:
                    case 1:
                        $('#status').html('<div id="startconvert" style="margin-top:3px;">   <b>Downloading video 100%...</b><br /> (This takes a few seconds..)</div>');
                        break;
                    case 2:
                        $('#status').html('<div id="startconvert" style="margin-top:3px;">   <b>Converting video.</b><br /> (This takes a few seconds..)</div>');
                        break;
                    case 3:
                        Complete = true;
                        DownloadVideo(Data.sid, Hash);
                        break
                }
                if (!Complete) {
                    window.setTimeout(function() {
                        ConvertVideo(Video, Hash)
                    }, 3000)
                }
            }
        })
    }

    function CheckVideo(Video, Format) {
        $.ajax({
            url: 'http://d.yt-downloader.org/check.php',
            dataType: 'jsonp',
            data: {
                v: Video,
                f: Format
            },
            success: function(Data) {
                if (0 < Data.error) {
                    $('#converter').before('<div id="error">' + Ea.check[Data.error] + '<br/><a href="">Please try to download other option.</a></div>');
                    $.ajax({
                        url: 'error.php',
                        async: false,
                        cache: false,
                        type: 'POST',
                        data: {
                            f: 1,
                            e: Data.error,
                            s: '',
                            v: Video,
                            h: ''
                        }
                    });
                    return false
                }
                if (Data.title == 'noname') {
                    $('#status').html('Please enter a valid YouTube Video ID.')
                } else {
                    $('#title').html(Data.title)
                }
                Hash = Data.hash;
                if (0 < parseInt(Data.ce)) {
                    DownloadVideo(Data.sid, Hash)
                } else {
                    ConvertVideo(Video, Hash)
                }
            }
        })
    }
    $(document).ready(function() {
        Video = $(".ytid").text();
        console.log(Video);
        if (Video.length == 11) {
            Conversion = true;
            CheckVideo(Video, "mp3")
        }
        return false;
    });
}