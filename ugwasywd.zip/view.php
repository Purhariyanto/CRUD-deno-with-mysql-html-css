<?php
ob_start();
include 'functions/youtube-func.php';
include 'fungsi.php';
include 'includes/block.php';
$code = $_GET['q'];
$arr = in_array($code,$block);
if ($code == $arr)
{
	header('Location: /');
	die;
}
if(is_numeric($_GET['q'])) :
	header('Location: /');
	die;
endif;
if($_GET['q'])
{
$q = $_GET['q'];
}
$qu = $q;
$qu = str_replace(' ','-',$qu);
$qu = str_replace('+','-',$qu);
$qu = str_replace('_','-',$qu);
$qu = str_replace('download-lagu-','',$qu);
$qu = str_replace('matikiri','',$qu);
$qu = str_replace('planetlagu','',$qu);
$qu = str_replace('stafaband','',$qu);
$qu = str_replace('uyeshare','',$qu);
$qu = str_replace('mp3','',$qu);
$qu = str_replace('download','',$qu);
$ks = $q;
$ks = str_replace('+',' ',$ks);
$ks = str_replace('-',' ',$ks);
$k = $q;
$k = str_replace('+',' ',$k);
$k = str_replace('-',' ',$k);
$mb = rand(2,10);

$description = 'Download lagu '.ucwords($ks).' MP3 Download, Video 3gp & mp4. List download link '.ucwords($ks).' and free streaming terbaru hanya di Dlagu.';
$description = str_replace('lagu Download Lagu','lagu',$description);
$description = str_replace('lagu Lagu','lagu',$description);
$description = str_replace('Download lagu Download','Download lagu',$description);
$description = str_replace('Mp3 Mp3','Mp3',$description);

$title = ''.ucwords($ks).' Mp3 Download - Dlagu';
$title = str_replace('Lagu Download Lagu','Lagu mp3',$title);
$title = str_replace('Lagu Lagu','Lagu',$title);
$title = str_replace('Lagu Download','Lagu',$title);
$title = str_replace('Download Download','Download',$title);
$title = str_replace('Mp3 Mp3','Mp3',$title);

include 'includes/head.php';
echo '<p class="menu" align="Justify"><strong>'.str_replace(' - Dlagu', '', $title).'</strong>. Belilah Kaset asli atau CD original dan unduh lagu aslinya di Itunes atau Amazon agar Musisi kesayangan anda dapat terus berkarya di Belantika Musik Dunia. '.str_replace(' - Dlagu', '', $title).' hanya untuk review saja.</p>';

$grab = ngegrab('https://www.googleapis.com/youtube/v3/search?part=snippet&q='.$qu.'&key=AIzaSyA-dlBUjVQeuc4a6ZN4RkNUYDFddrVLxrA&maxResults=30&type=video');
$json = json_decode($grab);
$pageinfo = $json->pageInfo->totalResults;
if($pageinfo == 0):
	header('location: /error.php');
	die;
endif;
echo '<div class="musics_list">';
foreach ($json->items as $hasil) :
$id = $hasil->id->videoId;
$title = $hasil->snippet->title;
$judul = ucwords(cleaned($title));
$judul = str_replace('-',' ', $judul);
$url = cleaned($title);

if(!bot()) :
echo '<div class="ok">';
echo '<h2>'.$judul.'</h2>';
echo '<a href="/downloadmp3/'.base64url_encode($id).'/'.trim($url, "-").'.html"><button class="new-button-fixed">DOWNLOAD</button></a>';
echo '</div>';
else :
	echo '<div class="ok">';
	echo '<a href="/downloadmp3/'.base64url_encode($id).'/'.trim($url, "-").'.html"><h2>'.$judul.'</h2></a>';
	echo '</div>';
endif;
endforeach;
echo '</div>';
if(empty($id)) :
	header('location: /error.php');
	die;
endif;

include 'last_search.php';
include 'includes/foot.php';
?>
