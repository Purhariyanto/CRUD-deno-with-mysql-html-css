<?php
include 'functions/youtube-func.php';
include 'includes/block.php';
include 'fungsi.php';
$code = base64url_decode($_GET['id']);
$arr = in_array($code,$blockdl);
if ($code == $arr)
{
	header('Location: /');
}

$mb = rand(2,15);
$yf=ngegrab('https://www.googleapis.com/youtube/v3/videos?key=AIzaSyA-dlBUjVQeuc4a6ZN4RkNUYDFddrVLxrA&part=snippet,contentDetails,statistics,status,topicDetails&id='.base64url_decode($_GET['id']).'');
$yf=json_decode($yf);
if($yf)
{
foreach ($yf->items as $item)
{
$name          = $item->snippet->title;
$des           = $item->snippet->description;
$date          = dateyt($item->snippet->publishedAt);
$channelTitle  = $item->snippet->channelTitle;
$channelId     = $item->snippet->channelId;
$contentDetails= $item->contentDetails;
$dimension     = $contentDetails->dimension;
$dimension     = str_replace('2d','2D',$dimension);
$dimension     = str_replace('3d','3D',$dimension);
$dur           = format_time($contentDetails->duration);
$hd            = $contentDetails->definition;
$statistics    = $item->statistics;
$views         = numberAbbreviation($statistics->viewCount);
$likes         = $statistics->likeCount;
$dislikes      = $statistics->dislikeCount;
$favoriteCount = $statistics->favoriteCount;
$commentCount  = $statistics->commentCount;
$status        = $item->status;
$privacy       = $status->privacyStatus;
$judul = ucwords(cleaned($name));
$judul = str_replace('-',' ', $judul);
$Ajudul = str_replace('-','+', $judul);
$name = str_replace('"','', $name);
$title = ''.trim($judul).' - Dlagu';
$description = ''.trim($judul).' dapat kamu download secara gratis hanya untuk review saja di news-manga.com. Jelajahi '.trim($judul).' tanpa batas MP3 download.'; //Add Description';
include 'includes/head.php';
echo '<div class="menu"><div align="center">';
echo '<p align="Justify"> Download Lagu dari <strong>'.trim($judul).' Mp3, Video MP4 & 3GP Gratis</strong>. '.trim($judul).'.mp3 gratis hanya untuk review saja, Belilah Kaset asli atau CD original dan unduh lagu aslinya di Itunes atau Amazon agar Musisi kesayangan anda dapat terus berkarya di Belantika Musik Dunia.</p>';
echo'</div>';
echo '<div class="content">';
echo '<div class="header" align="center"><strong><h2>'.trim($judul).'</h2></strong></div>';
echo '<br /><iframe src="/dl.php?id='.$_GET['id'].'" frameborder="0" width=" 100%" height="40" allowfullscreen></iframe><br /><br />';
echo '<div class="content">';
echo '<table style="width:100%">';
echo '<tbody>';
echo '<tr valign="top">';
echo '<td width="30%"> Title</td>';
echo '<td> :</td>';
echo '<td>'.trim($judul).'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"> Extensions</td>';
echo '<td> : </td>';
echo '<td>Mp3</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"> Duration</td>';
echo '<td> : </td>';
echo '<td> '.$dur.' </td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"> Channel</td>';
echo '<td> : </td>';
echo '<td>'.$channelTitle.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"> Added On</td>';
echo '<td> : </td>';
echo '<td>'.$date.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"> Views</td>';
echo '<td> : </td>';
echo '<td>'.$views.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"> Likes</td>';
echo '<td> : </td>';
echo '<td>'.$likes.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"> Source</td>';
echo '<td> : </td>';
echo '<td>Youtube.com</td>';
echo '</tr>';
echo '</tbody>';
echo '</table>';
echo '</div>';
if(!bot()) :
echo '<div class="content" align="center">';
echo '<br/><a class="menu" href="/mp3/'.$_GET['id'].'" title="'.trim($judul).'" rel="nofollow">DOWNLOAD</a><br/><br/>';
echo '</div>';
endif;
echo '<p align="justify"><strong>Tags : Unduh Lagu , Cari Lagu , StafaBand, 4share, bursamp3, wapkalagu, sharelagu, savelagu, mp3.li, azlyrics, mp3.zing.vn, Spotify, vimeo, waptrick, itunes, amazon.</strong></p>';
echo '</div>';
echo '<div class="title"><h4>Related Mp3</h4></div>';
$b = preg_replace('/[^a-zA-Z0-9\- ]/', '', $name);
$b = str_replace(' ','-', $b);
$b = str_replace('---','-', $b);
$b = str_replace('--','-', $b);
$grab = ngegrab('https://www.googleapis.com/youtube/v3/search?part=snippet&q='.$b.'&key=AIzaSyA-dlBUjVQeuc4a6ZN4RkNUYDFddrVLxrA&maxResults=5&type=video');
$json = json_decode($grab);
if($json)
{
foreach ($json->items as $hasil)
{
$id = $hasil->id->videoId;
$title = $hasil->snippet->title;
$judul = ucwords(cleaned($title));
$judul = str_replace('-',' ', $judul);
$url = cleaned($title);

echo '<div class="musics_list">';
echo '<table>';
echo '<tbody>';
echo '<tr valign="middle">';
echo '<td>';
echo '<ul>';
echo '<li><a href="/download/'.trim($url, "-").'" title="'.trim($judul).'" rel="dofollow">'.trim($judul).'</a></li>';
echo '</ul>';
echo '</td>';
echo '</tr>';
echo '</tbody>';
echo '</table>';
echo '</div>';
}
}
include 'includes/foot.php';
}
} else {
	header('Location: /');
}
?>
