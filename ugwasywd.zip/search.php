<?php
if(!empty($_GET['q']))
{
	if(is_numeric($_GET['q'])) :
		header('location: /');
		die;
	endif;
$b = preg_replace('/[^a-zA-Z0-9\- ]/', '', trim($_GET['q']));
$b = str_replace(' ','-', $b);
$b = str_replace('---','-', $b);
$b = str_replace('--','-', $b);
$url='/download/'.strtolower($b).'';
}
else
{
$url='/';
}
header('location:'.$url.'');
?>
